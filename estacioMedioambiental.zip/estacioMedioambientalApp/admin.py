from django.contrib import admin

from estacioMedioambientalApp.models import Client, Sensor, Registre, SensorType, Location


@admin.register(Client)
class ClientAdmin(admin.ModelAdmin):
    # fields = ("usuari", "identificador", "localitzacio",
    #           "quarentena", "dataQuarentena")
    list_display = ("usuari", "identificador", "localitzacio",
                    "quarentena", "dataQuarentena", "getQuantSensors", 'actiu', 'token')
    search_fields = ("usuari__username", "identificador", "localitzacio",
                     "dataQuarentena", "quarentena", 'actiu', 'token')
    list_filter = ('actiu', 'quarentena', "usuari")

    # "getQuantClient"
    # list_display = ("identificador", "localitzacio")
    # pass


@admin.register(Sensor)
class SensorAdmin(admin.ModelAdmin):
    list_display = ("identificador", "tipusSensor", "client")
    list_filter = ("tipusSensor", )
    search_fields = ("identificador", "tipusSensor", "client")

    pass


@admin.register(Location)
class LocationAdmin(admin.ModelAdmin):
    list_display = ("pais", "localitat", "latitud", "longitud", "altitud")
    list_filter = ("pais", )
    search_fields = ("pais", "localitat", "latitud", "longitud", "altitud")

    pass


@admin.register(Registre)
class RegistreAdmin(admin.ModelAdmin):
    list_display = ('valor', 'hora', 'sensor')
    search_fields = ('valor', 'hora', 'sensor')
    list_filter = ("hora", 'sensor')
    pass


@admin.register(SensorType)
class SensorTypeAdmin(admin.ModelAdmin):
    list_display = ('tipus', 'unitatMesura',
                    'valorMaximPotable', 'valorMinimPotable', 'valorMaxim', 'valorMinim')
    search_fields = ('tipus', 'unitatMesura',
                     'valorMaximPotable', 'valorMinimPotable', 'valorMaxim', 'valorMinim')
    list_filter = ("tipus", "unitatMesura")

    pass
