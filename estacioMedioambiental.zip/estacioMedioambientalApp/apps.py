from django.apps import AppConfig


class EstaciomedioambientalappConfig(AppConfig):
    name = 'estacioMedioambientalApp'
