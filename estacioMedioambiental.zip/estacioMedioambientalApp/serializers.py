from rest_framework import serializers
from estacioMedioambientalApp.models import Client, Sensor, Registre, SensorType, Location


class ClientSerializer(serializers.ModelSerializer):

    class Meta:
        model = Client
        fields = [
            'id',
            'identificador',
            'localitzacio',
            'quarentena',
            'dataQuarentena',
            'getQuantSensors',
            'getLocation',
            'token',
            'getSensors'
        ]


class SensorSerializer(serializers.ModelSerializer):

    class Meta:
        model = Sensor
        fields = [
            'identificador',
            'client',
            'tipusSensor'
        ]


class RegistreSerializer(serializers.ModelSerializer):

    class Meta:
        model = Registre
        fields = [
            'hora',
            'valor',
            'sensor'
        ]


class SensorTypeSerializer(serializers.ModelSerializer):

    class Meta:
        model = SensorType
        fields = [
            'tipus',
            'unitatMesura',
            'valorMaximPotable',
            'valorMinimPotable',
            'descripcio',
            'valorMaxim',
            'valorMinim',
        ]


class LocationSerializer(serializers.ModelSerializer):

    class Meta:
        model = Location
        fields = [
            'pais',
            'localitat',
            'latitud',
            'longitud',
            "altitud"
        ]
