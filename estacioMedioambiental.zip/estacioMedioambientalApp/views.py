from django.shortcuts import render
from django.views.generic.base import View
from django.http import JsonResponse
from rest_framework import viewsets
import json
from estacioMedioambientalApp.models import Client, Sensor, Registre, SensorType, Location
from estacioMedioambientalApp.serializers import ClientSerializer, SensorSerializer, RegistreSerializer, SensorTypeSerializer, LocationSerializer
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import authentication, permissions
from django.contrib.auth.models import User
from django.core import serializers
from rest_framework.renderers import JSONRenderer
from rest_framework.authentication import SessionAuthentication, BasicAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework.authtoken.models import Token
from rest_framework import status
from django.db.models import Q
from django.db.models import Count


################### API #####################

class ClientViewSet(viewsets.ModelViewSet):
    queryset = Client.objects.all()
    serializer_class = ClientSerializer


class SensorViewSet(viewsets.ModelViewSet):
    queryset = Sensor.objects.all()
    serializer_class = SensorSerializer


class SensorTypeViewSet(viewsets.ModelViewSet):
    queryset = SensorType.objects.all()
    serializer_class = SensorTypeSerializer


class RegistreViewSet(viewsets.ModelViewSet):
    #authentication_classes = [authentication.TokenAuthentication]
    #permission_classes = [permissions.IsAdminUser]
    queryset = Registre.objects.all()
    serializer_class = RegistreSerializer


class Paisos(APIView):

    # permission_classes = [permissions.IsAdminUser]

    def get(self, request, format=None):
        """
        Return a list of all users.
        """
        valors = [pais for pais in Location.objects.all().values(
            'pais').distinct()]
        return Response(valors)


class LocalitzacioPerPais(APIView):

    # permission_classes = [permissions.IsAdminUser]

    def get(self, request, format=None):
        """
        Return a list of all users.
        """

        valors = [pais for pais in Location.objects.all().values(
            'pais').distinct()]
        return Response(valors)


class ListRegistres(APIView):

    # permission_classes = [permissions.IsAdminUser]

    def get(self, request, format=None):
        """
        Return a list of all users.
        """
        # valors = [Registre.valor for Registre in Registre.objects.all()]

        # serializer = LocationSerializer(
        #     Location.objects.all().values('pais').distinct(), many=True)
        valors = [pais for pais in Location.objects.all().values(
            'pais').distinct()]
        # token = Token.objects.create(user=User.objects.filter())
        return Response(valors)


class GetSensorTypes(APIView):

    # permission_classes = [permissions.IsAdminUser]

    def get(self, request, format=None):
        """
        Retorna una llista de tots els .
        """
        serializer = SensorTypeSerializer(SensorType.objects.all(), many=True)
        return Response(serializer.data)


class ValuesFromClient(APIView):

    authentication_classes = [authentication.TokenAuthentication]
    # permission_classes = [permissions.IsAdminUser]

    def get(self, request, format=None):
        """
        Retorna una llista de tots els .
        """
        idClient = request.GET.get('id')
        user_id = Token.objects.get(key=request.auth.key).user_id
        user = User.objects.get(id=user_id)
        client = Client.objects.filter(id=idClient, actiu=True).first()
        if client.usuari != user:
            return Response("El client no es de la teva propietat", status=status.HTTP_404_NOT_FOUND)

        typusDeSensors = SensorType.objects.all()
        resultatFinal = {}
        for typusSensor in typusDeSensors:
            # Agafo tots els sensors dels clients de la ciutat demanada i amb el tipus concret
            sensors = Sensor.objects.filter(
                client=idClient, tipusSensor=typusSensor)

            if sensors:
                # Llistare els sensors com a filtres de els registres
                filtreRegistresClient = Q()
                for sensor in sensors:
                    filtreRegistresClient = filtreRegistresClient | Q(
                        sensor=sensor)

                # Agafare tots els registres de aqueslls sensors de la ciutat que no estiguin en quarentena
                registres = Registre.objects.filter(filtreRegistresClient)
                resultatFinal[typusSensor.toJSON()] = RegistreSerializer(
                    registres, many=True).data

        #serializer = SensorTypeSerializer(SensorType.objects.all(), many=True)
        return Response(resultatFinal)


class GetClientsFromUser(APIView):

    authentication_classes = [authentication.TokenAuthentication]
    # permission_classes = [permissions.IsAdminUser]

    def get(self, request, format=None):
        """
        Retorna una llista de tots els .
        """
        #user = Token.objects.get(key=authentication.TokenAuthentication).user
        user_id = Token.objects.get(key=request.auth.key).user_id
        user = User.objects.get(id=user_id)
        serializer = ClientSerializer(
            Client.objects.filter(usuari=user_id, actiu=True), many=True)
        return Response(serializer.data)


class login(APIView):

    # permission_classes = [permissions.IsAdminUser]

    def post(self, request, format=None):
        """
        Retorna una llista de tots els .
        """
        #user = Token.objects.get(key=authentication.TokenAuthentication).user
        user_id = Token.objects.get(key=request.auth.key).user_id
        user = User.objects.get(id=user_id)
        serializer = ClientSerializer(
            Client.objects.filter(usuari=user_id, actiu=True), many=True)
        return Response(serializer.data)


class GetClient(APIView):

    authentication_classes = [authentication.TokenAuthentication]
    # permission_classes = [permissions.IsAdminUser]

    def get(self, request, format=None):
        """
        Retorna el client per el id demanat
        """
        #user = Token.objects.get(key=authentication.TokenAuthentication).user
        idClient = request.GET.get('id')
        user_id = Token.objects.get(key=request.auth.key).user_id
        user = User.objects.get(id=user_id)
        client = Client.objects.filter(id=idClient, actiu=True).first()
        if client.usuari != user:
            return Response("El client no es de la teva propietat", status=status.HTTP_404_NOT_FOUND)
        else:
            serializer = ClientSerializer(client)
            return Response(serializer.data)


class Locations(APIView):

    # permission_classes = [permissions.IsAdminUser]

    def get(self, request, format=None):
        """
        Return a list of all users.
        """
        pais = request.GET.get('pais')
        # valors = [Registre.valor for Registre in Registre.objects.all()]

        clients = Client.objects.all()

        if not clients:
            return Response("No hi ha clients en la base de dades", status=status.HTTP_404_NOT_FOUND)

        filtreClients = Q()
        for client in clients:
            filtreClients = filtreClients | Q(id=client.localitzacio.id)

        if(pais):
            filtreClients = filtreClients & Q(pais=pais)
            serializer = LocationSerializer(
                Location.objects.filter(filtreClients), many=True)
        else:
            serializer = LocationSerializer(
                Location.objects.filter(filtreClients), many=True)
        return Response(serializer.data)


class DataByCity(APIView):

    # permission_classes = [permissions.IsAdminUser]

    def get(self, request, format=None):
        """
        Return a list of all users.
        """
        # Comprovacions de la peticio
        ciutat = request.GET.get('ciutat')
        pais = request.GET.get('pais')
        #sensorType = request.GET.get('sensor')

        if not ciutat:
            return Response("No hi ha ciutat", status=status.HTTP_404_NOT_FOUND)

        if not pais:
            return Response("No hi ha pais", status=status.HTTP_404_NOT_FOUND)

        # if not sensorType:
        #    return Response("No hi ha tipus de sensor", status=status.HTTP_404_NOT_FOUND)

        # Agafo localitzacio correcte
        location = Location.objects.filter(pais=pais, localitat=ciutat).first()

        # Comprovo que la localitzacio sigui valida
        if not location:
            return Response("No es una localitzacio valida", status=status.HTTP_404_NOT_FOUND)

        # Agafo els clients de aquella localitzacio i que no estiguin en quarentena
        clients = Client.objects.filter(
            localitzacio=location, quarentena=False)

        # Comprovo que hi hagin clients valids
        if not clients:
            return Response("No hi han clients en aquesta localitat o els que hi han estan en quarentena", status=status.HTTP_404_NOT_FOUND)

        # Els llisto com a filtres dels sensors
        filtreSensorClient = Q()
        for client in clients:
            filtreSensorClient = filtreSensorClient | Q(client=client)

        # Agafare els typus de sensors per crear un dicionari amb el nom del sensor
        typusDeSensors = SensorType.objects.all()
        resultatFinal = {}
        for typusSensor in typusDeSensors:
            # Agafo tots els sensors dels clients de la ciutat demanada i amb el tipus concret
            sensors = Sensor.objects.filter(
                filtreSensorClient, tipusSensor=typusSensor)

            if sensors:
                # Llistare els sensors com a filtres de els registres
                filtreRegistresClient = Q()
                for sensor in sensors:
                    filtreRegistresClient = filtreRegistresClient | Q(
                        sensor=sensor)

                # Agafare tots els registres de aqueslls sensors de la ciutat que no estiguin en quarentena
                registres = Registre.objects.filter(filtreRegistresClient)
                resultatFinal[typusSensor.toJSON()] = RegistreSerializer(
                    registres, many=True).data
                # return Response(resultatFinal)

        # Serialitzare els registres amb el serialitzado de django
        #serializer = RegistreSerializer(registres, many=True)

        return Response(resultatFinal)


class TestApi(APIView):

    authentication_classes = [authentication.TokenAuthentication]
    # permission_classes = [permissions.IsAdminUser]

    def get(self, request, format=None):
        """
        Prova per python
        """

        # return Response(request.data)
        return Response("Ok mister")

    def post(self, request, format=None):
        """
        Prova per python
        """

        return Response(request.data)
        # return Response("bon post crack")
